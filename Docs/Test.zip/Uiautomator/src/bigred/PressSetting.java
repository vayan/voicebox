package bigred;

import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.core.UiScrollable;
import com.android.uiautomator.core.UiSelector;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class PressSetting {

	public void testDemo() throws UiObjectNotFoundException {

		UiObject allAppsButton = new UiObject(new UiSelector().textContains("SETTING"));
		 
		allAppsButton.click();

	   }
	
}
