package bigred;

import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.core.UiScrollable;
import com.android.uiautomator.core.UiSelector;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class PressHistory extends UiAutomatorTestCase{
	public void testDemo() throws UiObjectNotFoundException {

		UiObject allAppsButton = new UiObject(new UiSelector().textContains("HESTORY"));
		 
		allAppsButton.click();

	   }
	
	
}
