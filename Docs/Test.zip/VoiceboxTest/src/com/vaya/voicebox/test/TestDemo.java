package com.vaya.voicebox.test;

import android.test.AndroidTestCase;
import junit.framework.TestCase;
import android.app.Activity;
import android.app.Instrumentation;
import android.test.ActivityInstrumentationTestCase2;
import android.test.UiThreadTest;
import android.test.suitebuilder.annotation.Suppress;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.vaya.voicebox.MainActivity;


public class TestDemo extends ActivityInstrumentationTestCase2
 {

	private Instrumentation mInstrument;
	private Activity mActivity;
	private View mView;

	
	public TestDemo() {
		super("com.vaya.voicebox.test",MainActivity.class);
	}

	
	protected void setUp() throws Exception {
		super.setUp();
		mInstrument = getInstrumentation();
		mActivity = getActivity();
		 //mView = mActivity.findViewById(com.vaya.voicebox.R.id.;
		mView=mActivity.findViewById(com.vaya.voicebox.R.id.button_start);
	}
	
	public void testPreConditions(){
		assertTrue(mView!=null);
		
	}
	
	public void testStartButton(){
		mInstrument.runOnMainSync(new Runnable() {
			
			@Override
			public void run() {
				mView.setPressed(true);
				
			}
		});
		
	}
	

}

